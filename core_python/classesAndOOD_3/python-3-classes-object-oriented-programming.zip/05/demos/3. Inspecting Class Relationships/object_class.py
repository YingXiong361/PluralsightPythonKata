class Employee(object):
    pass


e = Employee()
print(repr(e))
# This is the same as just print(e) in this case
