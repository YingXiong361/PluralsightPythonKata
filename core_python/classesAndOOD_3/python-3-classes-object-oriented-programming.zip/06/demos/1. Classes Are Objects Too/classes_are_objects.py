
s = "hello"


def fun():
    pass


class Employee:
    pass
